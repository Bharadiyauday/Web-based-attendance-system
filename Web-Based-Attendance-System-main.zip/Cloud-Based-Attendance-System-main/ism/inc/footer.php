	<div class="container mt-3">
		<div class="card card-body bg-light text-center">
			<h3>
				<span>Copyright &copy;</span>
				<script type="text/javascript">
					var d = new Date();
					document.write(d.getFullYear());
				</script>
				<span>
					<a target="_blank" href="">
						ISM PROJECT SRM
					</a>
				</span>
			</h3>
		</div>
	</div>
</body>
</html>